/// <reference types="ccxt" />
import { ConfigService } from '@nestjs/config';
import { Exchange } from './exchange/exchange.model';
export interface EntryOrderDto {
    symbol: string;
    side: 'buy' | 'sell';
    type: 'market' | 'limit';
    size: number;
    price?: number;
    prices?: number[];
    sizes?: number[];
    exchange: string;
    futures?: boolean;
}
export interface ExitOrderDto {
    symbol: string;
    side: 'buy' | 'sell';
    exchange: string;
    futures?: boolean;
    closeOrder: boolean;
}
interface ExchangeKey {
    apiKey: string;
    apiSecret: string;
}
export declare class TraderService {
    private configService;
    exchange: Exchange;
    constructor(configService: ConfigService<Record<string, ExchangeKey>>);
    order(order: EntryOrderDto | ExitOrderDto, dev?: boolean): Promise<string | import("ccxt").Order | import("ccxt").Order[]>;
    private initExchange;
    private parseTicker;
}
export {};
