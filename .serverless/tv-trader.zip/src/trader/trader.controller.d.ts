/// <reference types="ccxt" />
import { EntryOrderDto, TraderService } from './trader.service';
export declare class TraderController {
    private readonly traderService;
    constructor(traderService: TraderService);
    order(order: EntryOrderDto): Promise<string | import("ccxt").Order | import("ccxt").Order[]>;
    test(order: EntryOrderDto): Promise<string | import("ccxt").Order | import("ccxt").Order[]>;
}
