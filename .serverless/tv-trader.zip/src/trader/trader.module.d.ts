export declare class TraderModule {
}
