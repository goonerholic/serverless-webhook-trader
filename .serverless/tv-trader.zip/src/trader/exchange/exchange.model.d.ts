import ccxt from 'ccxt';
export interface CreateOrderPayload {
    symbol: string;
    type: 'market' | 'limit' | 'stop_market';
    side: 'buy' | 'sell';
    size: number;
    price?: number;
}
export declare class Exchange {
    exchange: ccxt.Exchange;
    constructor(exchangeId: string, apiKey: string, secret: string, futures?: boolean);
    fetchMarket(): Promise<ccxt.Dictionary<ccxt.Market>>;
    fetchPositions(symbol: string): Promise<any>;
    fetchOrders(symbol: string): Promise<ccxt.Order[]>;
    cancelOrder(id: string, symbol: string): Promise<ccxt.Order>;
    placeOrder(payload: CreateOrderPayload, clientId?: string): Promise<ccxt.Order>;
    closePosition(symbol: string, side: 'buy' | 'sell'): Promise<string>;
    closeAllPositions(symbol: string): Promise<string[]>;
}
