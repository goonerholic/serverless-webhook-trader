"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TraderService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const exchange_model_1 = require("./exchange/exchange.model");
let TraderService = class TraderService {
    constructor(configService) {
        this.configService = configService;
    }
    async order(order, dev = false) {
        this.initExchange(order.exchange, (order.futures = true), dev);
        const symbol = await this.parseTicker(order.symbol);
        if ('closeOrder' in order) {
            return await this.exchange.closePosition(symbol, order.side);
        }
        if ('prices' in order) {
            return await Promise.all(order.prices.map((price, index) => this.exchange.placeOrder({
                symbol,
                side: order.side,
                type: order.type,
                size: order.sizes[index],
                price,
            }, `${symbol}-entry-${Date.now()}-${index}`)));
        }
        return await this.exchange.placeOrder({
            symbol,
            type: order.type,
            side: order.side,
            size: order.size,
            price: order.price,
        });
    }
    initExchange(exchange, futures, dev) {
        const { apiKey, apiSecret, apiKeyDev, apiSecretDev } = this.configService.get(exchange);
        this.exchange = new exchange_model_1.Exchange(exchange, dev ? apiKeyDev : apiKey, dev ? apiSecretDev : apiSecret, futures);
    }
    async parseTicker(ticker) {
        const market = await this.exchange.fetchMarket();
        return Object.entries(market).find(([, value]) => value.id === ticker)[0];
    }
};
TraderService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], TraderService);
exports.TraderService = TraderService;
//# sourceMappingURL=trader.service.js.map