export declare const exchangeKeys: () => {
    binance: {
        apiKey: string;
        apiSecret: string;
        apiKeyDev: string;
        apiSecretDev: string;
    };
};
